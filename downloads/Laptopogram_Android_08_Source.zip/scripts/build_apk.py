#!/usr/bin/env python3
"""Build a signed Laptopogram APK with Android SDK 35 and Java 8+ compiler.
No network access and no Gradle are needed by this build script.
"""
import argparse, os, shutil, subprocess, sys, xml.etree.ElementTree as ET, zipfile
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--android-jar',type=Path,required=True)
p.add_argument('--build-tools',type=Path,required=True)
p.add_argument('--ecj',type=Path,help='Optional Eclipse compiler jar; otherwise uses javac')
p.add_argument('--keystore',type=Path,required=True)
p.add_argument('--password-file',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
root=Path(__file__).resolve().parents[1];build=root/'build/manual'
build.mkdir(parents=True,exist_ok=True)
for d in ['classes','dex']:
 if (build/d).exists():shutil.rmtree(build/d)
 (build/d).mkdir()
def run(args):subprocess.run([str(x) for x in args],check=True,cwd=root)
sources=sorted((root/'app/src/main/java').rglob('*.java'))
compiler=['java','-jar',a.ecj,'-8','-nowarn'] if a.ecj else ['javac','-source','8','-target','8','-encoding','UTF-8']
run(compiler+['-classpath',a.android_jar,'-d',build/'classes']+sources)
ns='http://schemas.android.com/apk/res/android'
ET.register_namespace('android',ns)
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml');manifest.getroot().set('package','io.github.ikonta.laptopogram')
manifest.write(build/'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
run([a.build_tools/'aapt2','compile','--dir',root/'app/src/main/res','-o',build/'resources.zip'])
run([a.build_tools/'aapt2','link','-o',build/'base.apk','-I',a.android_jar,'--manifest',build/'AndroidManifest.xml','--min-sdk-version','26','--target-sdk-version','35','--version-code','8','--version-name','0.8','-A',root/'app/src/main/assets',build/'resources.zip'])
run(['java','-cp',a.build_tools/'lib/d8.jar','com.android.tools.r8.D8','--lib',a.android_jar,'--min-api','26','--output',build/'dex']+sorted((build/'classes').rglob('*.class')))
with zipfile.ZipFile(build/'base.apk','a',zipfile.ZIP_DEFLATED) as z:
 for f in (build/'dex').glob('*.dex'):z.write(f,f.name)
run([a.build_tools/'zipalign','-f','4',build/'base.apk',build/'aligned.apk'])
a.output.parent.mkdir(parents=True,exist_ok=True)
run(['java','-jar',a.build_tools/'lib/apksigner.jar','sign','--ks',a.keystore,'--ks-key-alias','laptopogram','--ks-pass','file:'+str(a.password_file),'--out',a.output,build/'aligned.apk'])
run(['java','-jar',a.build_tools/'lib/apksigner.jar','verify','--verbose',a.output])
print(a.output)
