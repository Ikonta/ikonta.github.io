# Laptopogram Android 08 – testversion

## Installera på Pixel

1. Ladda ner och öppna `Laptopogram_Android_08.apk` på telefonen.
2. Om Android frågar, tillåt den aktuella filappen eller webbläsaren att installera APK-filen. Du kan återställa den inställningen efter installationen.
3. Starta Laptopogram från den nya appikonen. Sidhuvudet ska visa **ANDROID / 08**.

Appen kräver Android 8.0 eller senare. Den är byggd mot Android API 35. En uppdaterad Android System WebView behövs för gränssnittet.

## Prova först utan fotopapper

1. Behåll CAMERA360-fjärren parkopplad i telefonens Bluetooth-inställningar.
2. Öppna appen och välj **Testbild** eller en egen bild. Välj 2 sekunders exponering så att resultatet syns tydligt.
3. Fäll ut **Fjärrutlösare**. Det ska stå att Android-stödet är aktivt. Ingen knappinlärning behövs i Android-versionen.
4. Tryck **Aktivera fjärrläge**. Skärmen blir svart och väntar.
5. Tryck på telefonens volymknapp. Bilden ska visas i 2 sekunder och sedan försvinna. Volymreglaget ska inte visas i fjärrläge.
6. Gör samma prov med fjärrens knappar. Volym upp, volym ned, kamera, Enter och mellanslag stöds som utlösarsignaler.
7. När provet fungerar kan telefonen läggas med skärmen mot fotopapperet före fjärrutlösningen.

Fjärrutlösning använder ingen startfördröjning. Den vanliga fördröjda startknappen fungerar fortfarande separat.

Efter exponeringen förblir skärmen svart. Släpp fjärrknappen före nästa exponering. Hållna knappar, tryck under en pågående exponering och snabba dubbeltryck startar inte extra exponeringar.

Lyft telefonen och tryck på skärmen efter avslut för att öppna reglagen. Bakåt under svartläge stoppar exponeringen och behåller svart skärm. Aktivera fjärrläget på nytt efter avbrott, appbyte eller fokusförlust.

Utanför fjärrläget har telefonens volymknappar sin vanliga funktion.

## Vad Android-versionen gör

Den laddar en medföljande lokal kopia av Laptopogram i Android WebView. Android-aktiviteten fångar hårdvaruknapparna före WebView och använder en begränsad brygga till exponeringstimern. Det kringgår webbläsarens problem med volymknappar utan knappomkopplingsappar eller tillgänglighetsbehörigheter.

Appen begär inga nätverks-, kamera-, Bluetooth- eller generella lagringsbehörigheter. Bluetooth-parning sker i telefonens inställningar. En bild väljs via Androids systemväljare. Bilder och gränssnitt fungerar lokalt utan anslutning till ikonta eller ChatGPT. Delningsknappen öppnar telefonens delningsdialog med ikonta-länken.

Skärmen hålls vaken medan appen är öppen. Ljusstyrka och färginställningar ändras inte av appen. Svart bild stänger inte av LCD-bakbelysning. Den schemalagda exponeringstiden är fortfarande begränsad av skärmens uppdatering och WebView; använd provremsor.

## Kontrollerat i byggmiljön

- Java-koden har kompilerats mot Android API 35.
- Native-knappfiltret passerar 16 kontrollfall.
- 13 JavaScript-tester passerar för brygga, fjärrläge, upprepade tryck, fokusavbrott och fördröjd start.
- APK-filen är signerad och signaturen verifierad med Androids apksigner.
- APK-manifestet har kontrollerats: inga begärda behörigheter.

**Appen har ännu inte startats i en fysisk Android-telefon eller emulator. CAMERA360-fjärren är inte fysiskt verifierad.** Bygg- och komponentkontroller ersätter inte telefonprovet ovan.

## Källkod och egna byggen

Projektet kan öppnas i Android Studio. Gradle-konfigurationen använder Android Gradle Plugin 8.7.3, compile/target SDK 35 och min SDK 26. Källkodspaketet innehåller inga privata signeringsnycklar. Egna byggen får därför en annan signatur om du inte använder den ursprungliga signeringsnyckeln. Android kan kräva att den befintliga appen avinstalleras vid byte av signatur, vilket tar bort appens sparade inställningar.

Det medföljande `scripts/build_apk.py` är den byggväg som användes för den levererade APK-filen. Det kräver Android SDK build-tools 35.0.0, android.jar för API 35 och Java-kompilator. Det kan använda `javac` eller en separat Eclipse ECJ-jar. Verktygen hämtas inte automatiskt av skriptet. Exempel:

```
python scripts/build_apk.py \
  --android-jar /path/to/sdk/platforms/android-35/android.jar \
  --build-tools /path/to/sdk/build-tools/35.0.0 \
  --keystore /private/path/laptopogram.p12 \
  --password-file /private/path/password.txt \
  --output /path/to/Laptopogram.apk
```

Signeringsalias för skriptet är `laptopogram`. Lägg aldrig privata nycklar eller lösenord på den publika ikonta-sajten.

Referenser: Android KeyEvent, Activity.dispatchKeyEvent och WebView-dokumentationen på developer.android.com.
