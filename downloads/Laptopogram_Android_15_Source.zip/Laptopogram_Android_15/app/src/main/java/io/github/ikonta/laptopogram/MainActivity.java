package io.github.ikonta.laptopogram;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** Offline-only host: only bundled assets can execute scripts; no network permission. */
public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String PREFIX = "/assets/laptopogram/";
    private static final String HOME = "https://" + HOST + PREFIX + "index.html";
    private static final String PUBLIC_URL = "https://ikonta.github.io/laptopogram/";
    private static final int PICK_IMAGE = 100;
    private static final Set<String> FILES = new HashSet<>(Arrays.asList(
        "index.html", "app.mjs", "exposure-core.mjs", "styles.css", "icon-192.png"));
    private final RemoteKeyGate gate = new RemoteKeyGate();
    private volatile boolean resumed;
    private volatile boolean darkMode;
    private WebView web;
    private View curtain;
    private ValueCallback<Uri[]> imageCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        curtain = new View(this);
        curtain.setBackgroundColor(Color.BLACK);
        curtain.setVisibility(View.GONE);
        root.addView(curtain, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        // The system image picker grants access to one content URI, without broad storage permission.
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new RemoteBridge(), "LaptopogramAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String path = uri.getPath();
                if (trusted(uri) && path != null && path.startsWith(PREFIX)) {
                    String file = path.substring(PREFIX.length());
                    if (FILES.contains(file) && "GET".equals(request.getMethod())) {
                        try {
                            String mime = file.endsWith(".html") ? "text/html"
                                : file.endsWith(".css") ? "text/css"
                                : file.endsWith(".png") ? "image/png" : "application/javascript";
                            return new WebResourceResponse(mime, "UTF-8", 200, "OK",
                                Collections.singletonMap("Cache-Control", "no-store"),
                                getAssets().open("laptopogram/" + file));
                        } catch (IOException ignored) { }
                    }
                }
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
                    Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // The app never navigates to user-provided HTML or remote web pages.
                return !HOME.equals(request.getUrl().toString());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (imageCallback != null) imageCallback.onReceiveValue(null);
                imageCallback = callback;
                Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                picker.addCategory(Intent.CATEGORY_OPENABLE);
                picker.setType("image/*");
                try { startActivityForResult(picker, PICK_IMAGE); }
                catch (ActivityNotFoundException exception) {
                    imageCallback.onReceiveValue(null); imageCallback = null;
                }
                return true;
            }
        });
        immersive();
        web.loadUrl(HOME);
    }
    private boolean trusted(Uri uri) {
        return "https".equals(uri.getScheme()) && HOST.equals(uri.getHost())
            && uri.getPort() == -1 && uri.getUserInfo() == null;
    }
    private void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }
    public final class RemoteBridge {
        @JavascriptInterface public boolean isNativeHost() { return true; }
        @JavascriptInterface public void setDarkMode(boolean enabled) {
            boolean entering = enabled && !darkMode;
            darkMode = enabled;
            if (entering) runOnUiThread(() -> {
                InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (keyboard != null && web != null) keyboard.hideSoftInputFromWindow(web.getWindowToken(), 0);
                immersive();
            });
        }
        @JavascriptInterface public void setRemoteArmed(boolean enabled) {
            gate.setArmed(enabled && resumed);
        }
        @JavascriptInterface public void shareLink() {
            runOnUiThread(() -> {
                if (!resumed || gate.isArmed()) return;
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, PUBLIC_URL);
                try { startActivity(Intent.createChooser(send, "Laptopogram")); }
                catch (ActivityNotFoundException ignored) { }
            });
        }
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        int result = gate.accept(event.getKeyCode(), event.getAction(), event.getRepeatCount());
        if (result == RemoteKeyGate.PASS) return super.dispatchKeyEvent(event);
        if (result == RemoteKeyGate.TRIGGER && resumed && hasWindowFocus()) {
            web.evaluateJavascript("window.LaptopogramNative && window.LaptopogramNative.trigger()", null);
        }
        return true; // Both down and up are consumed, so Android does not change volume.
    }
    private void pauseExposure() {
        gate.setArmed(false);
        if (web == null || curtain == null) return;
        curtain.setVisibility(View.VISIBLE);
        web.evaluateJavascript("window.LaptopogramNative && window.LaptopogramNative.pause()", null);
    }
    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (!focus) pauseExposure();
        else {
            immersive();
            if (web != null && curtain != null) web.evaluateJavascript(
                "window.LaptopogramNative && window.LaptopogramNative.pause()",
                result -> { if (resumed && hasWindowFocus()) curtain.setVisibility(View.GONE); });
        }
    }
    @Override protected void onResume() {
        super.onResume(); resumed = true;
        if (web != null) web.onResume();
        immersive();
    }
    @Override protected void onPause() {
        resumed = false; pauseExposure();
        if (web != null) web.onPause();
        super.onPause();
    }
    @Override public void onBackPressed() {
        gate.setArmed(false);
        if (web == null) { finish(); return; }
        web.evaluateJavascript("window.LaptopogramNative ? window.LaptopogramNative.back() : false",
            result -> { if (!"true".equals(result)) finish(); });
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_IMAGE && imageCallback != null) {
            Uri selected = result == RESULT_OK && data != null ? data.getData() : null;
            if (selected != null && !"content".equals(selected.getScheme())) selected = null;
            imageCallback.onReceiveValue(selected == null ? null : new Uri[] { selected });
            imageCallback = null;
        }
    }
    @Override protected void onDestroy() {
        gate.setArmed(false);
        if (imageCallback != null) { imageCallback.onReceiveValue(null); imageCallback = null; }
        if (web != null) { web.removeJavascriptInterface("LaptopogramAndroid"); web.destroy(); }
        super.onDestroy();
    }
}
