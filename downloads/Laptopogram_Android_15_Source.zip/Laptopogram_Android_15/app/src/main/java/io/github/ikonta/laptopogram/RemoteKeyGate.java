package io.github.ikonta.laptopogram;

/** Receives Android's volume keys before WebView/AudioManager. */
public final class RemoteKeyGate {
    public static final int PASS = 0, CONSUME = 1, TRIGGER = 2;
    private boolean armed;
    private final java.util.HashSet<Integer> heldKeys = new java.util.HashSet<>();

    public synchronized void setArmed(boolean value) {
        if (armed != value) heldKeys.clear();
        armed = value;
    }
    public synchronized boolean isArmed() { return armed; }
    public synchronized int accept(int keyCode, int action, int repeatCount) {
        if (!armed || (keyCode != 24 && keyCode != 25 && keyCode != 27 && keyCode != 66 && keyCode != 160 && keyCode != 62)) return PASS;
        boolean held = heldKeys.contains(keyCode);
        if (action == 1) {
            heldKeys.remove(keyCode);
            return CONSUME;
        }
        if (action != 0) return CONSUME;
        heldKeys.add(keyCode);
        return repeatCount == 0 && !held ? TRIGGER : CONSUME;
    }
}
