import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('check_css', ROOT / 'scripts/check_css.py')
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)


class StyleValidation(unittest.TestCase):
    def test_mobile_regression_rejects_missing_min_parenthesis(self):
        with self.assertRaises(ValueError):
            validator.check_css('.preview-well{width:min(100%,calc(38svh * var(--screen-ratio,1))}')

    def test_comments_and_quoted_content_are_not_delimiters(self):
        validator.check_css('/* ) } */ .a::before { content: "( [ }"; width: calc(100% - 1px); }')

    def test_packaged_styles_are_balanced(self):
        for path in (ROOT / 'app/src/main/assets').rglob('*.css'):
            validator.check_css(path.read_text())


if __name__ == '__main__':
    unittest.main()
