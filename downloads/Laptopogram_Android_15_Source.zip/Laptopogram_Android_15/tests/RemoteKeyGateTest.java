import io.github.ikonta.laptopogram.RemoteKeyGate;
public class RemoteKeyGateTest {
    private static void eq(int expected, int actual) { if (expected != actual) throw new AssertionError(expected + " != " + actual); }
    public static void main(String[] args) {
        RemoteKeyGate gate = new RemoteKeyGate();
        eq(0, gate.accept(24,0,0)); // Volume works normally before arming.
        gate.setArmed(true);
        eq(2,gate.accept(24,0,0));
        eq(1,gate.accept(24,0,1));
        eq(1,gate.accept(24,0,0)); // Duplicate down is not a second print.
        eq(1,gate.accept(24,1,0));
        eq(2,gate.accept(24,0,0));
        eq(1,gate.accept(24,1,0));
        eq(2,gate.accept(25,0,0));
        eq(1,gate.accept(25,1,0));
        eq(0,gate.accept(30,0,0)); // Other keyboard keys remain available.
        gate.setArmed(false);
        eq(0,gate.accept(25,0,0));
        gate.setArmed(true);
        eq(2,gate.accept(25,0,0)); // Re-arming clears held state.
        eq(2,gate.accept(66,0,0));
        eq(1,gate.accept(66,1,0));
        eq(2,gate.accept(27,0,0));
        eq(1,gate.accept(27,1,0));
        System.out.println("Native key gate: 16 assertions passed");
    }
}
