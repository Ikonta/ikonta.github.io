import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {ExposureTimer,exposureDurations,fitImage,processPixels} from '../app/src/main/assets/laptopogram/exposure-core.mjs';
function app(options={}){
 const nativeStates=[];
 const els=new Map(), wh=new Map(), dh=new Map(), timeouts=new Map(), storage=new Map();let now=0, frame, seq=0;
 const ctx=()=>({calls:[],fillRect(){this.calls.push('black')},drawImage(){this.calls.push('image')},save(){},restore(){},beginPath(){},rect(){},clip(){},translate(){},scale(){},rotate(){},clearRect(){},fillText(){},arc(){},stroke(){},moveTo(){},lineTo(){},putImageData(){},getImageData(){return {data:new Uint8ClampedArray(16)}}});
 function el(tag='div'){const handlers=new Map(),c=ctx();return {tag,value:'',checked:false,hidden:false,textContent:'',dataset:{},style:{setProperty(){}},classList:{add(){},remove(){},toggle(){}},getContext:()=>c,context:c,getBoundingClientRect:()=>({width:300,height:500}),addEventListener:(k,v)=>handlers.set(k,v),emit(k,event={}){handlers.get(k)?.({target:this,...event})},click(){this.emit('click')},focus(){},setAttribute(){},setCustomValidity(s){this.invalid=!!s},checkValidity(){return !this.invalid},reportValidity(){},replaceChildren(){this.children=[]},children:[],append(...xs){this.children.push(...xs)},closest(){return ['input','select'].includes(tag)?this:null}}}
 const html=readFileSync(new URL('../app/src/main/assets/laptopogram/index.html',import.meta.url),'utf8');
 for(const m of html.matchAll(/<([a-z][a-z0-9]*)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){const e=el(m[1]);e.value=/\bvalue="([^"]*)"/.exec(m[2])?.[1]||'';e.checked=/\bchecked\b/.test(m[2]);e.hidden=/\bhidden\b/.test(m[2]);els.set(m[3],e)}
 els.get('delay').value='10000';els.get('mode').value='single';els.get('rotation').value='0';
 if (!options.defaults) storage.set('skarmkopia-v1',JSON.stringify(options.preferences ?? {duration:'500',timeDefaultRevision:12}));
 if (options.language !== null) storage.set('laptopogram-language',options.language ?? 'sv');
 const document={body:el(),documentElement:el('html'),hidden:false,fullscreenElement:null,hasFocus:()=>true,getElementById:id=>els.get(id),createElement:el,querySelectorAll:()=>[],addEventListener:(k,v)=>dh.set(k,v)};
 const context={document,window:{scrollTo(){},innerWidth:390,innerHeight:750,addEventListener:(k,v)=>wh.set(k,v),LaptopogramAndroid:options.native?{isNativeHost:()=>true,setRemoteArmed:v=>nativeStates.push(v),shareLink(){}}:undefined},navigator:{languages:['sv']},localStorage:{getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v)},devicePixelRatio:1,performance:{now:()=>now},requestAnimationFrame:fn=>{frame=fn;return 1},cancelAnimationFrame:()=>frame=null,setTimeout:(fn)=>{const id=++seq;timeouts.set(id,fn);return id},clearTimeout:id=>timeouts.delete(id),Date,console,ExposureTimer,exposureDurations,fitImage,processPixels};
 vm.runInNewContext(readFileSync(new URL('../app/src/main/assets/laptopogram/app.mjs',import.meta.url),'utf8').replace(/^import[^\n]+\n/,''),context);
 return {native:context.window.LaptopogramNative,nativeStates,get:id=>els.get(id),document,storage,key(code,key=code,repeat=false,type='keydown'){let prevented=false;wh.get(type)?.({code,key,repeat,target:document.body,preventDefault(){prevented=true}});return prevented},tick(t){now=t;const f=frame;frame=null;f?.(t)},at(t){now=t},timeout(){for(const [id,f] of timeouts){timeouts.delete(id);f()}},hide(){document.hidden=true;dh.get('visibilitychange')()}};
}
function learn(a,code='Enter',key='Enter'){a.get('remoteLearn').click();assert.equal(a.key(code,key),true);a.key(code,key,false,'keyup')}
function finish(a,start,duration=500){a.tick(start);for(let t=start+100;t<=start+duration;t+=100)a.tick(t)}
test('Remote arm stays black and learned button exposes immediately instead of using the 10 s delay',()=>{const a=app();a.get('demo').click();learn(a);a.get('remoteArm').click();a.tick(100);assert.equal(a.get('exposure').context.calls.at(-1),'black');a.at(200);a.key('Enter');a.tick(200);assert.equal(a.get('exposure').context.calls.at(-1),'image');assert.equal(a.get('delay').value,'10000')});
test('Held, duplicate and busy presses do not queue another exposure; a fresh press can expose after completion',()=>{const a=app();a.get('demo').click();learn(a);a.get('remoteArm').click();a.key('Enter');a.tick(0);a.key('Enter','Enter',true);a.key('Enter');finish(a,100,400);assert.equal(a.get('log').children.length,1);a.tick(600);assert.equal(a.get('exposure').context.calls.at(-1),'black');a.key('Enter','Enter',false,'keyup');a.at(1100);a.key('Enter');a.tick(1100);assert.equal(a.get('exposure').context.calls.at(-1),'image')});
test('Learning a volume key with no code uses key and never fires an exposure during calibration',()=>{const a=app();a.get('demo').click();learn(a,'','AudioVolumeUp');assert.equal(a.get('darkroom').hidden,true);a.get('remoteArm').click();a.key('','AudioVolumeUp');a.tick(0);assert.equal(a.get('exposure').context.calls.at(-1),'image');assert.equal(a.storage.get('laptopogram-remote'),'key:AudioVolumeUp')});
test('No-event test times out and does not claim a working remote or enable remote arm',()=>{const a=app();a.get('demo').click();a.get('remoteLearn').click();a.timeout();assert.match(a.get('remoteStatus').textContent,/Ingen signal/);assert.equal(a.get('remoteArm').disabled,true)});
test('Remote cannot arm before image selection; wrong keys are ignored',()=>{const a=app();learn(a);assert.equal(a.get('remoteArm').disabled,true);a.get('demo').click();a.get('remoteArm').click();a.key('Space',' ');a.tick(0);assert.equal(a.get('exposure').context.calls.at(-1),'black')});
test('Hiding the page aborts a remote exposure to black',()=>{const a=app();a.get('demo').click();learn(a);a.get('remoteArm').click();a.key('Enter');a.tick(0);a.hide();assert.equal(a.get('exposure').context.calls.at(-1),'black');assert.equal(a.get('log').children.length,1)});
test('The original delayed mobile start still waits for its selected delay',()=>{const a=app();a.get('demo').click();a.get('chooseDelay').click();a.get('mobileStart').click();a.tick(9999);assert.equal(a.get('exposure').context.calls.at(-1),'black');a.tick(10000);assert.equal(a.get('exposure').context.calls.at(-1),'image')});
test('Remote labels exist in all three languages and language switch preserves the learned button',()=>{const a=app();a.get('demo').click();learn(a);a.get('language').value='ja';a.get('language').emit('change');assert.match(a.get('remoteStatus').textContent,/登録/);assert.equal(a.get('remoteArm').disabled,false);a.get('language').value='en';a.get('language').emit('change');assert.match(a.get('remoteStatus').textContent,/registered/)});
test('Escape disarms remote standby and prevents an accidental exposure',()=>{const a=app();a.get('demo').click();learn(a);a.get('remoteArm').click();a.key('Escape');a.key('Enter');a.tick(0);assert.equal(a.get('exposure').context.calls.at(-1),'black')});

test('A learned Space key cannot trigger a manual exposure after remote mode is disarmed',()=>{const a=app();a.get('demo').click();learn(a,'Space',' ');a.get('remoteArm').click();a.key('Escape');a.key('Space',' ');a.tick(10000);assert.equal(a.get('exposure').context.calls.at(-1),'black');assert.equal(a.get('log').children.length,0)});


test('Android mode needs no learning and native volume signal starts a direct exposure',()=>{const a=app({native:true});a.get('demo').click();assert.equal(a.get('remoteLearn').hidden,true);assert.equal(a.get('remoteArm').disabled,false);a.get('remoteArm').click();assert.equal(a.nativeStates.at(-1),true);assert.equal(a.native.trigger(),true);a.tick(0);assert.equal(a.get('exposure').context.calls.at(-1),'image');assert.equal(a.native.trigger(),false);finish(a,100,400);assert.equal(a.get('log').children.length,1);assert.equal(a.nativeStates.at(-1),true)});
test('Android pause blanks the surface, disarms native keys and requires re-arming',()=>{const a=app({native:true});a.get('demo').click();a.get('remoteArm').click();a.native.trigger();a.tick(0);assert.equal(a.native.pause(),true);assert.equal(a.get('exposure').context.calls.at(-1),'black');assert.equal(a.nativeStates.at(-1),false);a.at(20000);assert.equal(a.native.trigger(),false);assert.equal(a.get('darkroom').hidden,false)});
test('Android back in controls permits closing; volume cannot trigger outside remote mode',()=>{const a=app({native:true});a.get('demo').click();assert.equal(a.native.back(),false);assert.equal(a.native.trigger(),false);a.get('mobileStart').click();assert.equal(a.native.trigger(),false)});

test('About blocks exposure shortcuts and returning keeps the selected image and delay',()=>{const a=app({native:true});a.get('demo').click();a.get('chooseDelay').click();a.get('delay').value='3000';a.get('delay').emit('change');const name=a.get('filename').textContent;a.get('aboutTab').click();assert.equal(a.get('workView').hidden,true);assert.equal(a.get('aboutView').hidden,false);a.key('KeyF','f');assert.equal(a.get('darkroom').hidden,true);a.get('language').value='ja';a.get('language').emit('change');assert.equal(a.get('aboutView').hidden,false);assert.equal(a.get('delay').value,'3000');a.get('language').value='sv';a.get('language').emit('change');a.get('workTab').click();assert.equal(a.get('workView').hidden,false);assert.equal(a.get('aboutView').hidden,true);assert.equal(a.get('filename').textContent,name);assert.equal(a.get('remoteArm').disabled,false);a.get('mobileStart').click();a.tick(2999);assert.equal(a.get('exposure').context.calls.at(-1),'black');a.tick(3000);assert.equal(a.get('exposure').context.calls.at(-1),'image')});

test('The single Start button follows the remote choice and returns to the selected self-timer delay',()=>{const a=app({native:true});a.get('chooseRemote').click();assert.equal(a.get('mobileStart').disabled,true);a.get('demo').click();assert.equal(a.get('delayRow').hidden,true);assert.equal(a.get('mobileStart').disabled,false);assert.equal(a.get('mobileStartLabel').textContent,'Vänta på fjärren');a.get('mobileStart').click();a.tick(10000);assert.equal(a.get('exposure').context.calls.at(-1),'black');assert.equal(a.native.trigger(),true);a.tick(10000);assert.equal(a.get('exposure').context.calls.at(-1),'image');const b=app({native:true});b.get('demo').click();b.get('chooseRemote').click();b.get('chooseDelay').click();assert.equal(b.get('delayRow').hidden,false);b.get('mobileStart').click();b.tick(9999);assert.equal(b.get('exposure').context.calls.at(-1),'black');b.tick(10000);assert.equal(b.get('exposure').context.calls.at(-1),'image')});
test('Editing seconds preserves millisecond timing and saved settings',()=>{const a=app({native:true});a.get('demo').click();a.get('chooseDelay').click();a.get('exposureSeconds').value='0.125';a.get('exposureSeconds').emit('input');assert.equal(a.get('duration').value,'125');assert.equal(JSON.parse(a.storage.get('skarmkopia-v1')).duration,'125');a.get('delay').value='0';a.get('delay').emit('change');a.get('mobileStart').click();a.tick(0);assert.equal(a.get('exposure').context.calls.at(-1),'image');a.tick(125);assert.equal(a.get('exposure').context.calls.at(-1),'black');assert.equal(a.get('log').children.length,1)});
test('Browser remote choice keeps the shared Start button disabled until a key is learned',()=>{const a=app();a.get('demo').click();a.get('chooseRemote').click();assert.equal(a.get('remoteSetup').hidden,false);assert.equal(a.get('mobileStart').disabled,true);learn(a);assert.equal(a.get('mobileStart').disabled,false);a.get('mobileStart').click();a.key('Enter');a.tick(0);assert.equal(a.get('exposure').context.calls.at(-1),'image')});


test('Fresh installs and older saved timings start at 2 seconds; new timings survive restore',()=>{const a=app({defaults:true,native:true});assert.equal(a.get('duration').value,'2000');assert.equal(a.get('exposureSeconds').value,'2');const b=app({preferences:{duration:'500'},native:true});assert.equal(b.get('duration').value,'2000');const c=app({preferences:{duration:'4000',timeDefaultRevision:12},native:true});assert.equal(c.get('duration').value,'4000')});
test('Time arrows halve or double and stop at the supported boundaries',()=>{const a=app({defaults:true,native:true});a.get('timeDown').click();assert.equal(a.get('duration').value,'1000');a.get('timeDown').click();assert.equal(a.get('duration').value,'500');a.get('timeUp').click();assert.equal(a.get('duration').value,'1000');let prevented=false;a.get('exposureSeconds').emit('keydown',{code:'ArrowUp',preventDefault(){prevented=true}});assert.equal(prevented,true);assert.equal(a.get('exposureSeconds').value,'2');a.get('timeUp').click();a.get('timeUp').click();a.get('timeUp').click();assert.equal(a.get('duration').value,'16000');assert.equal(a.get('timeUp').disabled,true);a.get('timeUp').click();assert.equal(a.get('duration').value,'16000');a.get('exposureSeconds').value='0.05';a.get('exposureSeconds').emit('input');assert.equal(a.get('timeDown').disabled,true);a.get('timeDown').click();assert.equal(a.get('duration').value,'50')});
test('Changing time during an exposure does not alter its duration',()=>{const a=app({defaults:true,native:true});a.get('demo').click();a.get('chooseRemote').click();a.get('mobileStart').click();a.native.trigger();a.tick(0);a.get('timeDown').click();assert.equal(a.get('duration').value,'2000');assert.equal(a.get('exposure').context.calls.at(-1),'image')});

test('Returning from black mode does not leave a stale message claiming the screen is black',async()=>{const a=app({native:true});a.get('demo').click();a.get('chooseRemote').click();a.get('mobileStart').click();a.get('darkroom').click();await Promise.resolve();assert.equal(a.get('darkroom').hidden,true);assert.equal(a.get('status').hidden,true);a.get('mobileStart').click();a.native.pause();a.get('darkroom').click();await Promise.resolve();assert.equal(a.get('darkroom').hidden,true);assert.equal(a.get('status').textContent,'Exponeringen avbröts. Starta på nytt.');assert.equal(a.get('status').hidden,false)});


test('Start actions stay hidden until the corresponding method is chosen',()=>{
 const a=app({native:true});
 for(const id of ['delayRow','remoteSetup','mobileStart']) assert.equal(a.get(id).hidden,true);
 a.get('demo').click();assert.equal(a.get('mobileStart').hidden,true);
 a.get('mobileStart').click();assert.equal(a.get('darkroom').hidden,true);
 a.get('chooseDelay').click();assert.equal(a.get('delayRow').hidden,false);assert.equal(a.get('mobileStart').hidden,false);
 assert.match(a.get('mobileStartLabel').textContent,/10/);
 a.get('chooseRemote').click();assert.equal(a.get('delayRow').hidden,true);assert.equal(a.get('mobileStartLabel').textContent,'Vänta på fjärren');
 a.get('chooseDelay').click();assert.equal(a.get('delayRow').hidden,false);assert.match(a.get('mobileStartLabel').textContent,/10/);
});
test('Rotation advances by quarters, returns to its origin and survives restoration',()=>{
 const a=app();a.get('demo').click();
 for(const expected of ['90','180','270','0']) {a.get('rotation').click();assert.equal(a.get('rotation').value,expected);assert.equal(JSON.parse(a.storage.get('skarmkopia-v1')).rotation,expected)}
 const b=app({preferences:{rotation:'270'}});assert.equal(b.get('rotation').value,'270');b.get('rotation').click();assert.equal(b.get('rotation').value,'0');
 const c=app({preferences:{rotation:'bad'}});assert.equal(c.get('rotation').value,'0');
});
test('About offers a back arrow and both the arrow and title return home without losing settings',()=>{
 const a=app();a.get('demo').click();a.get('rotation').click();
 assert.equal(a.get('aboutBack').hidden,true);
 a.get('aboutTab').click();assert.equal(a.get('aboutBack').hidden,false);assert.equal(a.get('workView').hidden,true);
 a.get('aboutTab').click();assert.equal(a.get('aboutBack').hidden,true);assert.equal(a.get('workView').hidden,false);
 a.get('aboutTab').click();a.get('workTab').click();assert.equal(a.get('aboutView').hidden,true);assert.equal(a.get('rotation').value,'90');
});


test('English is the default on a Swedish device when no language has been saved',()=>{
 const a=app({defaults:true,language:null,native:true});
 assert.equal(a.document.documentElement.lang,'en');assert.equal(a.get('language').value,'en');assert.equal(a.storage.get('laptopogram-language'),'en');
 const b=app({language:'unsupported'});assert.equal(b.document.documentElement.lang,'en');
});
test('A deliberate Swedish or Japanese language choice survives application startup',()=>{
 for(const language of ['sv','ja']) {const a=app({language});assert.equal(a.document.documentElement.lang,language);assert.equal(a.get('language').value,language)}
});
