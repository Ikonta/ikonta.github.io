# Laptopogram Android 15 – testversion

## Gränssnitt 0.15

Negative och Mirror är flyttade åt höger och jämnt fördelade tillsammans med rotationsknappen. Tidspilarna är ersatta med större, fyllda pilsymboler. Engelska används som standardspråk vid första start oavsett telefonens språk. Ett tidigare valt språk behålls.

## Övrigt gränssnitt

- Rotationssymbolen vrider bilden 90 grader medurs för varje tryck: 0, 90, 180, 270 och tillbaka till 0. Vald rotation sparas. Spegelvändning utgår från den roterade bilden.
- Tidsvärdet är centrerat med enheten under. Knapparna visar en nedåtpil respektive uppåtpil och halverar respektive dubblerar tiden.
- Inget startsätt är förvalt. Först efter ett tryck på Självutlösare visas Starta om och startknappen. Fjärrutlösare visar Vänta på fjärren. Byte mellan alternativen behåller vald fördröjning.
- Bildrutan har samma bredd och ungefär två tredjedelar av den tidigare höjden. Bilder visas utan förvrängning; exponeringen använder fortfarande hela skärmens yta.
- Sidhuvudet visar Laptopogram, Om och en språklista. Laptopogram leder tillbaka till arbetsytan. På Om visas en vänsterpil vid Om-knappen; knappen leder då tillbaka. Bild och inställningar behålls vid byten.

Formgivningen behåller svart sidhuvud, neutralgrå bakgrund, ljusa paneler, blå reglage och orange-röd startknapp. Standardtiden är 2 sekunder. Egna tider valda i version 0.12 eller senare behålls vid uppdatering. Historik är infällbar, och instruktioner och delning finns under Om.

## Installera på Pixel

1. Ladda ner och öppna `Laptopogram_Android_15.apk` på telefonen.
2. Om Android frågar, tillåt den aktuella filappen eller webbläsaren att installera APK-filen. Du kan återställa den inställningen efter installationen.
3. Starta Laptopogram från den nya appikonen. Versionen visas under **Om** som Android 0.15. Installera som uppdatering över tidigare version; samma signeringsnyckel används.

Appen kräver Android 8.0 eller senare. Den är byggd mot Android API 35. En uppdaterad Android System WebView behövs för gränssnittet.

## Prova först utan fotopapper

1. Behåll CAMERA360-fjärren parkopplad i telefonens Bluetooth-inställningar.
2. Öppna appen och välj **Testbild** eller en egen bild. Ange 2 i tidsfältet (sekunder) så att resultatet syns tydligt.
3. Välj **Fjärrutlösare** under Start och tryck **Vänta på fjärren**. Ingen knappinlärning behövs i Android-versionen.
4. Skärmen blir svart och väntar.
5. Tryck på telefonens volymknapp. Bilden ska visas i 2 sekunder och sedan försvinna. Volymreglaget ska inte visas i fjärrläge.
6. Gör samma prov med fjärrens knappar. Volym upp, volym ned, kamera, Enter och mellanslag stöds som utlösarsignaler.
7. När provet fungerar kan telefonen läggas med skärmen mot fotopapperet före fjärrutlösningen.

Fjärrutlösning använder ingen startfördröjning. Välj Självutlösare för fördröjd exponering; samma orange startknapp följer det valda sättet.

Efter exponeringen förblir skärmen svart. Släpp fjärrknappen före nästa exponering. Hållna knappar, tryck under en pågående exponering och snabba dubbeltryck startar inte extra exponeringar.

Lyft telefonen och tryck på skärmen efter avslut för att öppna reglagen. Bakåt under svartläge stoppar exponeringen och behåller svart skärm. Aktivera fjärrläget på nytt efter avbrott, appbyte eller fokusförlust.

Utanför fjärrläget har telefonens volymknappar sin vanliga funktion.

## Vad Android-versionen gör

Den laddar en medföljande lokal kopia av Laptopogram i Android WebView. Android-aktiviteten fångar hårdvaruknapparna före WebView och använder en begränsad brygga till exponeringstimern. Det kringgår webbläsarens problem med volymknappar utan knappomkopplingsappar eller tillgänglighetsbehörigheter.

Appen begär inga nätverks-, kamera-, Bluetooth- eller generella lagringsbehörigheter. Bluetooth-parning sker i telefonens inställningar. En bild väljs via Androids systemväljare. Bilder och gränssnitt fungerar lokalt utan anslutning till ikonta eller ChatGPT. Delningsknappen öppnar telefonens delningsdialog med ikonta-länken.

Skärmen hålls vaken medan appen är öppen. Ljusstyrka och färginställningar ändras inte av appen. Svart bild stänger inte av LCD-bakbelysning. Den schemalagda exponeringstiden är fortfarande begränsad av skärmens uppdatering och WebView; använd provremsor.

## Kontrollerat i byggmiljön

- Java-koden har kompilerats mot Android API 35.
- Native-knappfiltret passerar 16 kontrollfall.
- 26 JavaScript-tester passerar för bland annat startval, rotation, navigering, språkbyte, fjärrläge, upprepade tryck och fokusavbrott.
- Rotation och spegelvändning har kontrollerats med verkliga bildpixlar i 10 fall, inklusive alla fyra orienteringar och återgången till utgångsläget.
- Tre CSS-kontroller passerar, inklusive en regression för en saknad parentes.
- APK-signaturen är verifierad och signeringscertifikatet matchar version 0.13.
- APK-manifestet anger version 0.15 och inga begärda behörigheter. Medföljande gränssnittsfiler matchar källkoden.

Version 0.15 har inte körts på fysisk telefon. Den visuella webbläsarkontrollen kunde inte genomföras för denna version. Layout och hårdvaruknappar behöver därför provas på mobilen.

## Källkod och egna byggen

Projektet kan öppnas i Android Studio. Gradle-konfigurationen använder Android Gradle Plugin 8.7.3, compile/target SDK 35 och min SDK 26. Källkodspaketet innehåller inga privata signeringsnycklar. Egna byggen får därför en annan signatur om du inte använder den ursprungliga signeringsnyckeln. Android kan kräva att den befintliga appen avinstalleras vid byte av signatur, vilket tar bort appens sparade inställningar.

Det medföljande `scripts/build_apk.py` är den byggväg som användes för den levererade APK-filen. Det kräver Android SDK build-tools 35.0.0, android.jar för API 35 och Java-kompilator. Det kan använda `javac` eller en separat Eclipse ECJ-jar. Verktygen hämtas inte automatiskt av skriptet. Exempel:

```
python scripts/build_apk.py \
  --android-jar /path/to/sdk/platforms/android-35/android.jar \
  --build-tools /path/to/sdk/build-tools/35.0.0 \
  --keystore /private/path/laptopogram.p12 \
  --password-file /private/path/password.txt \
  --output /path/to/Laptopogram.apk
```

Signeringsalias för skriptet är `laptopogram`. Lägg aldrig privata nycklar eller lösenord på den publika ikonta-sajten.

Referenser: Android KeyEvent, Activity.dispatchKeyEvent och WebView-dokumentationen på developer.android.com.
