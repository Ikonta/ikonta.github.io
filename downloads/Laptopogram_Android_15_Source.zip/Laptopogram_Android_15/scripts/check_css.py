#!/usr/bin/env python3
"""Reject unbalanced CSS delimiters before packaging assets.

This catches the missing parenthesis which caused the mobile browser to discard
all the following layout rules. Actual rendering is checked in a browser too.
"""
from pathlib import Path
import sys


def check_css(source):
    stack = []
    quote = None
    comment = False
    escaped = False
    line = 1
    pairs = {')': '(', ']': '[', '}': '{'}
    i = 0
    while i < len(source):
        c = source[i]
        if c == '\n':
            line += 1
        if comment:
            if source[i:i + 2] == '*/':
                comment = False
                i += 2
                continue
        elif quote:
            if escaped:
                escaped = False
            elif c == '\\':
                escaped = True
            elif c == quote:
                quote = None
        elif source[i:i + 2] == '/*':
            comment = True
            i += 2
            continue
        elif c in "\"'":
            quote = c
        elif c in '([{':
            stack.append((c, line))
        elif c in ')]}':
            if not stack or stack[-1][0] != pairs[c]:
                expected = stack[-1] if stack else 'no open delimiter'
                raise ValueError(f'Line {line}: unexpected {c!r}; open delimiter: {expected}')
            stack.pop()
        i += 1
    if quote or comment or stack:
        raise ValueError(f'Unclosed CSS token: {quote or ("comment" if comment else stack[-1])}')


if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    files = [Path(x) for x in sys.argv[1:]] or list((root / 'app/src/main/assets').rglob('*.css'))
    for path in files:
        try:
            check_css(path.read_text())
        except ValueError as error:
            raise SystemExit(f'{path.name}: {error}')
    print(f'CSS delimiters valid: {len(files)} file(s)')
